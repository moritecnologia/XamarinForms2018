﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using App2_ListaBrasil.Modelo;

namespace App2_ListaBrasil
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Estados : ContentPage
	{
		public Estados ()
		{
			InitializeComponent ();

            ListaEstados.ItemsSource = Servico.Servico.GetEstados();
		}
        /*É utilizado o private em vez do public, porque faz referência ao  método que será utilizado no XAML relacionado à este code-
         behind, não precisando ser public*/
        private void SelecaoEstadoAction(object sender, SelectedItemChangedEventArgs args)
        {
            /*Precisando utilizar o "using App2_ListaBrasil.Modelo;"*/
            Estado estado = (Estado) args.SelectedItem;

            Navigation.PushAsync(new Municipios(estado));
        }

    }
}