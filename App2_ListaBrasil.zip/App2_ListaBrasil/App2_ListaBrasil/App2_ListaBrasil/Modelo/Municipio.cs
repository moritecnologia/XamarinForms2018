﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App2_ListaBrasil.Modelo
{
    public class Municipio
    {
        public int id { get; set; }
        public string nome { get; set; }
    }
}
