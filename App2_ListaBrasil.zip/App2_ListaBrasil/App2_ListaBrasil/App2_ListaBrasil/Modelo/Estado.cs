﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App2_ListaBrasil.Modelo
{
    public class Estado
    {
        public int id { get; set; }
        public string sigla { get; set; }
        public string nome { get; set; }
    }
}
